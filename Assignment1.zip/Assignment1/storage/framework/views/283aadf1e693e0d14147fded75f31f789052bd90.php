 <!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<script src="https://code.jquery.com/jquery-3.3.1.js"></script> 

<link rel="stylesheet" href="<?php echo e(asset('./css/chosen.css')); ?>"/>
     <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

<script >
 
 
// $('.del').click(function() {

//      var  ied = $(this).attr('id');
//      window.location.href = "http://127.0.0.1:8000/admin/delete/"+ied;
      
// });

// function pop(){
//   alert("yooooooooooooo");
// }
 $(document).ready(function(){
 

  
    $.noConflict();
    var table = $('#example').DataTable();

$('#hello').click(function(){

alert("hi");
});


   


});

//for summernote


</script>


<!-- include summernote css/js -->
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
 
 <link rel="stylesheet" href="<?php echo e(asset('./css/datatable.css')); ?>"/>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <!-- <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style> -->
    </head>
    <body>
        <!-- <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    Laravel
                </div>

                <div class="links">
                    <a href="https://laravel.com/docs">Documentation</a>
                    <a href="https://laracasts.com">Laracasts</a>
                    <a href="https://laravel-news.com">News</a>
                    <a href="https://forge.laravel.com">Forge</a>
                    <a href="https://github.com/laravel/laravel">GitHub</a>
                </div>
            </div>
        </div> -->

  <div class="card">
      <div class="row" >
      
        <form action="<?php echo e(url('/adminlogin')); ?>" role="form" class="login-wrapper" method="post">
              <?php echo e(csrf_field()); ?>

          <div class="header">
            <div class="row">
              <div class="col-md-12 user-profile-pic">
                <h3><img src="http://127.0.0.1:8000/img/iandweone.png" alt="Logo" style="margin-top:-20px;" ></h3>
               <h3>Admin Login</h3>
              </div>
            </div>
          </div>
          <div class="content">
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                
                <input id="email" type="input col-md-12 col-sm-12 email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="example@example.com" required autofocus>
                  <?php if($errors->has('email')): ?>
                      <span class="help-block" style="color:red">
                          <strong><?php echo e($errors->first('email')); ?></strong>
                      </span>
                  <?php endif; ?>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12 col-sm-12">
                 <input id="password" type="password" type="col-md-12 col-sm-12" class="form-control" name="password" placeholder="********" required style="margin-top: 20px">
                  <?php if($errors->has('password')): ?>
                    <span class="help-block">
                      <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                  <?php endif; ?>
              </div>
            </div>
          </div>
          <div class="actions">
            <button class="btn" type="submit" style="background:#e8b563;color:white">Login</button>
            <a class="link" href="#">Forgot Password?</a>
            <div class="clearfix"></div>
          </div>
        </form>

      </div>
    </div>

<script type="text/javascript">
    document.body.style.backgroundImage = "url('https://res.cloudinary.com/dd54feugx/image/upload/v1538033997/cmscover_fy7h5j.jpg')";
   document.body.style.backgroundSize = "cover";
</script>
    </body>
</html>