<?php $__env->startSection('content'); ?>
    <div id="show1" style="margin-left: 100px; background-color: white; margin-top: 15px;">
    <h3 class="page-title">Users</h3>
    
    <div class="panel panel-default">
        <div class="panel-heading">
            View
        </div>
        
        <div class="panel-body">
            <div class="row">
                <div class="col-md-6">
                    <table class="table table-bordered table-striped">
                        <tr><th>Name</th>
                    <td><?php echo e($user->name); ?></td></tr><tr><th>Email</th>
                    <td><?php echo e($user->email); ?></td></tr><tr><th>Password</th>
                    <td>---</td></tr><tr><th>Role</th>
                    <td><?php echo e($user->role); ?></td></tr><tr><th>Remember token</th>
                    <td><?php echo e($user->remember_token); ?></td></tr>
                    </table>
                </div>
            </div>

            <p>&nbsp;</p>

            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-default">Back to list</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>