<?php $__env->startSection('content'); ?>

    <div id="create" style="margin-left: 120px; margin-top: 10px; background-color: white;">
    <h3 class="page-title">Users</h3>
 

    <div class="panel panel-default">
        <div class="panel-heading">
            Create
        </div>
        
        <div class="panel-body" style="margin-left: 280px;">
            <div class="row">
                <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
                    <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" id="name" class="form-control" placeholder="<?php echo e($user->name); ?>">
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="id" value="<?php echo e($user->id); ?>" id="id" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" id="display_name" class="form-control" placeholder="<?php echo e($user->email); ?>">
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="Password" name="password" id="description" class="form-control">
                        </div>
                        <div>
                            <label> Role </label><br/>
                            <select>
                                <option value="admin"> Admin </option>
                                <option value="user"> User </option>
                            </select>
                        
                        </div>
                        <div class="form-group">
                             <button type="submit" class="btn btn-primary pull-right">Submit
                                </button>
                                <button type="reset" class="btn btn-warning pull-left">Reset
                                </button>
                            
                        </div>
                        <?php if(count($errors)): ?>
                            <div class="alert alert-danger">
                               <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </ul>
                            </div>
                        <?php endif; ?>
                    </form>
    </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>