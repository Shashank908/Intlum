@extends('layouts.app')

@section('content')

    <div id="create" style="margin-left: 120px; margin-top: 10px; background-color: white;">
    <h3 class="page-title">Users</h3>
 

    <div class="panel panel-default">
        <div class="panel-heading">
            Create
        </div>
        
        <div class="panel-body" style="margin-left: 280px;">
            <div class="row">
                <form method="POST" action="{{ route('users.update', $user->id) }}">
                    {{ csrf_field() }}
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" id="name" class="form-control" placeholder="{{$user->name}}">
                        </div>
                        <div class="form-group">
                            <input type="hidden" name="id" value="{{$user->id}}" id="id" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" id="display_name" class="form-control" placeholder="{{$user->email}}">
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="Password" name="password" id="description" class="form-control">
                        </div>
                        <div>
                            <label> Role </label><br/>
                            <select>
                                <option value="admin"> Admin </option>
                                <option value="user"> User </option>
                            </select>
                        
                        </div>
                        <div class="form-group">
                             <button type="submit" class="btn btn-primary pull-right">Submit
                                </button>
                                <button type="reset" class="btn btn-warning pull-left">Reset
                                </button>
                            
                        </div>
                        @if(count($errors))
                            <div class="alert alert-danger">
                               <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach 
                                </ul>
                            </div>
                        @endif
                    </form>
    </div>
    </div>

@endsection

