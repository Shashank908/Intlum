<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta http-equiv="cache-control" content="private, max-age=0, no-cache"/>
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="expires" content="0">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}"/>

    <title> My App  @yield('title')</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="{{ asset('./css/cstyle.css') }}" rel="stylesheet"/>
   <!--  <link href="{{ asset('./css/editor.css') }}" rel="stylesheet"/> -->
   <!-- Include external CSS. -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.25.0/codemirror.min.css">
 
    <!-- Include Editor style. -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.5/css/froala_editor.pkgd.min.css" rel="stylesheet" type="text/css" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.5/css/froala_style.min.css" rel="stylesheet" type="text/css" />
    <link href="{{ asset('./css/editor.css') }}" rel="stylesheet"/>
    

 <link rel="stylesheet" href="{{ asset('./css/fonti.css') }}"/>

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
  <link rel="shortcut icon" type="img/x-icon" href="ra.png" />

<script src="https://code.jquery.com/jquery-3.3.1.js"></script> 

<link rel="stylesheet" href="{{ asset('./css/chosen.css') }}"/>
     <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

<script >
 
 
// $('.del').click(function() {

//      var  ied = $(this).attr('id');
//      window.location.href = "http://127.0.0.1:8000/admin/delete/"+ied;
      
// });

// function pop(){
//   alert("yooooooooooooo");
// }
 $(document).ready(function(){
 

  
    $.noConflict();
    var table = $('#example').DataTable();

$('#hello').click(function(){

alert("hi");
});


   


});

//for summernote


</script>


<!-- include summernote css/js -->
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
 
 <link rel="stylesheet" href="{{ asset('./css/datatable.css') }}"/>
</head>

<body>
    <div id="app">
     
                        
                           @if (Auth::guard()->guest())
                     
                            @yield('content')

                        @else
                                
                               <!-- <label> Course Admin : </label> -->
                                <mheader> </mheader>

                                <div class="main-container">
                                    <msidebar></msidebar>
                                  
                                   @yield('content')
                                </div>

                                
                                   
                                
                       @endif
                    </div>
                  


        <script type="text/javascript">
        @yield('scripts1')
    </script>
        <script type="text/javascript">
        @yield('scripts2')
    </script>

    <script type="text/javascript" src="{{asset('./js/app.js')}}"></script>
    <script src="/js/summernote.min.js"></script>
   
    <script src="/js/multipicker.min.js"></script>
    <script type="text/javascript" src="{{asset('./js/plus.js')}}"></script>
 

    
 
</body>
</html>