<template>
    <!-- Sidebar start -->
      <div class="sidebar hidden-xs">
        <div class="user-profile-pic">
         <br><br>
         </div>
        <ul class="slick-menu">
          <li class="active">
            <a href="{route('home')}">
              <div class="current-page">    </div>
                <span class="fs1" aria-hidden="false">   
                <i class="fa fa-tachometer" aria-hidden="false"></i></span>
                <strong>Dashboard</strong>
            </a>
          </li>
          
          
          <li class="drop-menu">
            <a href="/home">
              <span class="fs1" ><i class="fa fa-user-secret" aria-hidden="true"></i></span>
              <small>3</small>
              <strong>Admins</strong>
            </a>
            
          </li>
        </ul>
      </div>
      <!-- Sidebar end -->

</template>