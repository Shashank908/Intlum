<template>
  
    <!-- Header start -->
    <header>

      <!-- Logo start -->
      <div class="logo">
     
        <div class="user-profile-pic">
          <img src="https://res.cloudinary.com/dd54feugx/image/upload/v1544677128/logo_hiza3f.png" >
        </div>
      
      </div>
      

      <!-- Mini navigation start -->
      <div id="mini-nav" class="hidden-phone">
        <ul>

   <!-- Search bar start -->
      <div class="custom-search hidden-phone">
        <input type="text" class="search-query">
        <button> <span class="fs1" ><i class="fa fa-search" style="color:#e5c79d" aria-hidden="true"></i></span></button>
      </div>
      <!-- Search bar end -->


          <li class="hidden-sm">
            <a href="#">Abouts
              <span class="fs1" ><i class="fa fa-info-circle"></i></span>
            
            </a>
           
          </li>


          <li class="hidden-sm">
            <a href="#">
              <span class="fs1" ><i class="fa fa-bell" aria-hidden="true"></i></span>
              <span class="count-label">6</span>
            </a>
          
          </li>
         
          <li>
            <a href="http://localhost/assignment/Assignment/public/users/logout">
              <span class="text-label"> Shashank Shekhar </span><span class="fs1"></span>
            </a>
            <ul class="user-summary">
              <li>
                <div class="summary">
                  <div class="user-pic">
                    <img src="https://res.cloudinary.com/dd54feugx/image/upload/v1544677128/logo_hiza3f.png" alt="shashank"/>
                  </div>
                  <div class="basic-details">
                    <h4 class="no-margin">Shashank Shekhar</h4>
                    <h5 class="no-margin"> My Company</h5>
                    <small>Kolkata,India</small>
                  </div>
                         <div class="clearfix"></div>         
                </div>
              </li>
              <li>
                <a href="http://localhost/assignment/Assignment/public/users/logout"><button class="btn btn-danger btn-md" style="margin-bottom:40px;">Logout</button></a>
                <span class="clearfix"></span>
              </li>
            </ul>
          </li>
        </ul>
      </div>
      <!-- Mini navigation end -->

    </header>
    <!-- Header end -->

</template>

<script>

   export default
       {
         data: () => ({
             csrf: document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
           }),        
     };

</script>